fun main() {
    for (number in 0..10 step 2) {
        println("Number : $number")
    }
}