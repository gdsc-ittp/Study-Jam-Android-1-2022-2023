fun main() {
    var number = 1
    while (number < 10) {
        println(number)
        number++
    }
}