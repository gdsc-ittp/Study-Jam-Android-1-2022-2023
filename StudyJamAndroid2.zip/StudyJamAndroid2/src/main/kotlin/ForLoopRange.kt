fun main() {
    for (number in 1..10) {
        println("Number : $number")
    }
}