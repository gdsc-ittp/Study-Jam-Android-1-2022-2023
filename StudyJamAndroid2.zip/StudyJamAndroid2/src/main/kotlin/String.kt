fun main() {
    var name: String = "Abdul Hafiz Ramadan"
    var campus: String = "Institut Teknologi Teknologi Purwokerto"

    println(name)
    println(campus)
}