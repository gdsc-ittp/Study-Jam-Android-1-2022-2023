fun main() {
    var hashtag: Char = '#'
    var dollar: Char = '$'
    println(hashtag)
    println(dollar)
}