fun main() {
    printHello(null)
    println("Abdul")
}

fun printHello(name: String?): Unit {
    println("Hello $name")
}