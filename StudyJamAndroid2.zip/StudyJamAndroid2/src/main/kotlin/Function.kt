fun main() {
    helloWorld()
}

fun helloWorld() {
    println("Hello World!")
    println("Study Jam Android #4")
}