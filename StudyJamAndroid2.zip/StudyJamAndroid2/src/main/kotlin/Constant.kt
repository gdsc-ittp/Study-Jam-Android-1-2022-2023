const val EVENT = "Study Jam Android"
const val BATCH = 1

fun main() {
    println("Selamat datang di $EVENT, Batch $BATCH")
}