fun main() {
    sayHello("Abdul", "Ramadan")
    sayHello("GDSC", "ITTP")
}

fun sayHello(firstName: String, lastName: String) {
    println("Hello, $firstName $lastName")
}