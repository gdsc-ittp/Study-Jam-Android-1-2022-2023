fun main() {
    val names = arrayOf(
        "Abdul",
        "Hafiz",
        "Ramadan"
    )
    println(names.size)
    println(names[0])
    println(names[2])
}