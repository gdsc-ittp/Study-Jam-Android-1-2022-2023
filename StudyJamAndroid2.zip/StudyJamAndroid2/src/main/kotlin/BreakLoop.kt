fun main() {
    var number = 1
    while (true) {
        println(number)
        number++
        if (number == 100) break
    }
}