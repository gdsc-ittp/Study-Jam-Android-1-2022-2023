fun main() {
    val value = 10
    if (value > 15) {
        println("Good job")
    } else if (value > 10) {
        println("Nice Try")
    } else {
        println("Try again")
    }
}