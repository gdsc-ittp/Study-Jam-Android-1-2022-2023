fun main() {
    var name: String? = "Abdul"
    // name = null
    println(name?.length)
}