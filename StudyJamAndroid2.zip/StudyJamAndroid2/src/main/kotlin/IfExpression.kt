fun main() {
    val value = 5
    if (value > 5) {
        println("Good job")
    } else {
        println("Try again")
    }
}