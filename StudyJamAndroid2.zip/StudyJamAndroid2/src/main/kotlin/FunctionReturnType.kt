fun main() {
    val result = sum(10, 15) // 25
    println(sum(10, 5)) // 15
}

fun sum(num1: Int, num2: Int): Int {
    val total = num1 + num2
    return total
}