fun main() {
    var number: Int = 100

    // Conversi Tipe Data
    var byte: Byte = number.toByte()
    var short: Short = number.toShort()
    var int: Int = number.toInt()
    var long: Long = number.toLong()

    // Casting Tipe Data
    // var byte2: Long = number as Long // Error
}