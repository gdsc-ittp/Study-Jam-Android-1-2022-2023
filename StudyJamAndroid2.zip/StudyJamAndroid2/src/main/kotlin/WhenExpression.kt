fun main() {
    val number = 10
    when (number) {
        15 -> println("Good Job")
        10 -> println("Nice Try")
        else -> println("Try Again")
    }
}