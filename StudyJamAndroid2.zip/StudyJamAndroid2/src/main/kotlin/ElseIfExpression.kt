fun main() {
    val value = 10
    if (value > 5) {
        println("Good job")
    }
}