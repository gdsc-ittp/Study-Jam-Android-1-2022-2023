fun main() {
    var decimalLiteral = 100
    var hexadecimalLiteral = 0xFFEF
    var binaryLiteral = 0b1100
    println(decimalLiteral)
    println(hexadecimalLiteral)
    println(binaryLiteral)
}