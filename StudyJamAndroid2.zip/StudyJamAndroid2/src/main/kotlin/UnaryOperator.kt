fun main() {
    var a = 10
    a++ // 10 + 1 = 11
    a-- // 11 - 1 = 10
}