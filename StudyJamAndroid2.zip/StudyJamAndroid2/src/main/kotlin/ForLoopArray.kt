fun main() {
    val events = arrayOf("Study", "Jam", "Android")
    for (event in events) {
        println("Event : $event")
    }
}