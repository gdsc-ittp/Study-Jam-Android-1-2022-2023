fun main() {

    var age: Byte = 20
    var distance: Short = 140
    var height: Int = 190
    var balance: Long = 100_000_000L

    var number = 10

    println(age)
    println(distance)
    println(height)
    println(balance)

    println(number)
}