fun main() {
    val value = 11
    when {
        value > 15 -> println("Good job")
        value > 10 -> println("Not bad")
        else -> println("Try again")
    }
}