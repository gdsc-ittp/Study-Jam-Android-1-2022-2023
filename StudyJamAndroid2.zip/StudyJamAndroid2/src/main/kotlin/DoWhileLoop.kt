fun main() {
    var number = 1
    do {
        println(number)
        number++
    } while (number < 10)
}