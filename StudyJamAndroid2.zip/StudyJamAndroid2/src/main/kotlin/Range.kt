fun main() {
    val range = 1..10
    val reversedRange = 100 downTo 1
}
