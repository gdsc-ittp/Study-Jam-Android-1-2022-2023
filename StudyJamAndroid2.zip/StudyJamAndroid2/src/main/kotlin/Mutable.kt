fun main() {
    var pacar = "Si Dia"
    println("Pacar saya $pacar")
    pacar = "Si Kamu"
    println("Pacar saya $pacar")
}