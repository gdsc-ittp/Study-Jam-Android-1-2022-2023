fun main() {
    fun sayHello(name: String) {
        println("Hello, $name!")
    }
    sayHello("Abdul")
}