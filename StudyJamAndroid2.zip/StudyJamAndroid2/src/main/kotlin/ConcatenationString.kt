fun main() {
    var firstName = "Abdul"
    var lastName = "Ramadan"

    var fullName = firstName + " " + lastName
    println(fullName)
}