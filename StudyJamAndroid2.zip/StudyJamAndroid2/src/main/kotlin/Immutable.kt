fun main() {
    val pacar = "Si Dia"
    println("Pacar saya $pacar")
    // pacar = "Si Kamu"
    println("Pacar saya $pacar")




}