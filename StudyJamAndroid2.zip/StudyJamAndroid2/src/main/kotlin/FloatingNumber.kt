fun main() {
    var value: Float = 32.12F
    var radius: Double = 231321.23129839

    var nilai = 12.12

    println(value)
    println(radius)
    println(nilai)
}