fun main() {
    var name = "Abdul"

    println("Hello, " + name)
    println("Hello, $name")
    println("Panjang nama : ${1+1}")
}