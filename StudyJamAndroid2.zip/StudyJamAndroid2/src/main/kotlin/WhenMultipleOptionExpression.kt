fun main() {
    val number = 30
    when (number) {
        15, 20, 25 -> println("Good Job")
        10 -> println("Nice Try")
        else -> println("Try Again")
    }
}